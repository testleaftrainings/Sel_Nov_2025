package week4.day1;

public abstract class Axis implements RBI {
	
	//implemented method
	public void houseLoan() {
		System.out.println("1 Crore");
	}
	
	//unimplemented method
	public abstract void carLoan();
	
	

}
