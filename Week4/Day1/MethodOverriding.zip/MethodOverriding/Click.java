package week4.day1;

public class Click {
	
	public void click() {
		System.out.println("Element Clicked by XPath");

	}

}
