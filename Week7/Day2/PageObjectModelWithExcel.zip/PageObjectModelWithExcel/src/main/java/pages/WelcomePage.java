package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class WelcomePage extends BaseClass {
	//                              //acbd1234
	public WelcomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MyHomePage clickCrmsfaLink() {
		driver.findElement(By.partialLinkText("CRM")).click();
        return new MyHomePage(driver);   //acbd1234
	}

}
