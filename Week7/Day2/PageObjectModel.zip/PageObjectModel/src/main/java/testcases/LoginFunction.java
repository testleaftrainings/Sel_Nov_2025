package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class LoginFunction extends BaseClass {
@Test
	public void login() {
		LoginPage lp =new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton();

	}
	
}
