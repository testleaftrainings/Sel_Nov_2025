package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {
	
	 @And("Enter the username as {string}")
	public void enter_the_username_as_demosalesmanager(String username) {
	   driver.findElement(By.id("username")).sendKeys(username);
	}
	
	@And("Enter the password as {string}")
	public void enter_the_password_as_crmsfa(String password) {
	   driver.findElement(By.id("password")).sendKeys(password);
	}
	

	@When("Click the Login")
	public void click_the_login() {
	    driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should be logged in")
	public void it_should_be_logged_in() {
	   System.out.println("Login is successful");
	}
	
	@But("It should error message")
	public void it_should_error_message() {
	    System.out.println("It throws error message");
	}
}
