package learnreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnextentReport {

	public static void main(String[] args) {
		// Step1: Setup the path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/leaftaps.html");
		
		//Step2: Create the testcase
		ExtentReports extent=new ExtentReports();
		
		//Step3:
		extent.attachReporter(reporter);
		
		//Step4: adding the testcase
		ExtentTest test = extent.createTest("CreateLead", "CreateLead with multiple data");
		
		//Step5: assign details for testcase
		test.assignAuthor("Vineeth");
		test.assignCategory("Regression");
		
		//Step6: Closing the report
		extent.flush();
		
		System.out.println("Code completed");
		
	}

}
