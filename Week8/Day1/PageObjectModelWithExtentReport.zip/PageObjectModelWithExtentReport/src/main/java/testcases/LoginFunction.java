package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class LoginFunction extends BaseClass {
	@BeforeTest
	public void setValues() {
		filename="Login";
		
		testcaseName="Login";
		testcaseDescription="Login with multiple scenario";
		testcaseAuthor="Hari";
		testcaseCategory="Smoke";

	}
	
@Test(dataProvider = "sendData")
	public void login(String username,String password) throws IOException {
		LoginPage lp =new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();

	}
	
}
