package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	//public ChromeDriver driver;
	
	
	private static final ThreadLocal<ChromeDriver> driver=new ThreadLocal<ChromeDriver>();
	
	public String filename;
	
	public String testcaseName, testcaseDescription,testcaseAuthor,testcaseCategory;
	
	public static ExtentReports extent;
	
	public static ExtentTest test;
	
	
	public void setDriver() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
        driver.set(new ChromeDriver(opt));
	}
	
	public ChromeDriver getDriver() {
	  ChromeDriver chromeDriver = driver.get();
      return chromeDriver;
	}
	
	
	
	
	@BeforeMethod
	public void preConditions() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
		//driver=new ChromeDriver(opt); 
		setDriver();
		//acbd1234
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}
	@AfterMethod
    public void postConditions() {
		getDriver().close();	

	}
	@BeforeSuite
	public void startReport() {
		// Step1: Setup the path
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/leaftaps.html");
				
				//Step2: Create the testcase
				extent=new ExtentReports();
				
				//Step3:
				extent.attachReporter(reporter);

	}
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testcaseName, testcaseDescription);
		test.assignAuthor(testcaseAuthor);
		test.assignCategory(testcaseCategory);
	}
	
	public void reportStep(String status,String message) throws IOException {
		
		if(status.equalsIgnoreCase("Pass")) {
		  test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
		}
		
    }
	
	public int takeSnap() throws IOException {
		
		int randomNumber = (int)(Math.random()*999999+99999);
		
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		
		File destination=new File("./Snaps/image"+randomNumber+".png");
		
		FileUtils.copyFile(source, destination);
		
		return randomNumber;

	}
	
	
	@DataProvider
	public String[][] sendData() throws IOException {
		String[][] readData = ReadExcel.readData(filename);
		return readData;

	}

}
