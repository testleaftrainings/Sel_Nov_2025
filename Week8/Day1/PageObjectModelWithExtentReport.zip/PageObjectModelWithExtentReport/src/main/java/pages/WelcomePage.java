package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	
	@Then("It should be logged in")
	public void loginSuccess() {
		System.out.println("Login is successful");
	}
	@But("It should error message")
	public void errorMessage() {
		System.out.println("It should throw error message");

	}
	
	@When("Click on the crmsfa link")
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.partialLinkText("CRM")).click();
        return new MyHomePage();   //acbd1234
	}

}
