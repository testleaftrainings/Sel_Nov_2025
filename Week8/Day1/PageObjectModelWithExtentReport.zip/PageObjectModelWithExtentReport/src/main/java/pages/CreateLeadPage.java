package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
	
	
	@Given("Enter the Companyname as {string}")
	public CreateLeadPage enterCompanyName(String company) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(company);
        return this;
	}
	@And("Enter the Firstname as {string}")
	public CreateLeadPage enterFirstName(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
        return this;
	}
	@And("Enter the Lastname as {string}")
    public CreateLeadPage enterLastName(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
    return this;
	}
@When("Click on the Createlead button")
public ViewLeadPage clickCreateLeadButton() {
	
	getDriver().findElement(By.name("submitButton")).click();
	return new ViewLeadPage();   //acbd1234
}

}
