package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	//public ChromeDriver driver;
	
	
	private static final ThreadLocal<ChromeDriver> driver=new ThreadLocal<ChromeDriver>();
	
	public String filename;
	
	
	public void setDriver() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
        driver.set(new ChromeDriver(opt));
	}
	
	public ChromeDriver getDriver() {
	  ChromeDriver chromeDriver = driver.get();
      return chromeDriver;
	}
	
	
	
	
	@BeforeMethod
	public void preConditions() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
		//driver=new ChromeDriver(opt); 
		setDriver();
		//acbd1234
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}
	@AfterMethod
    public void postConditions() {
		getDriver().close();	

	}
	@DataProvider
	public String[][] sendData() throws IOException {
		String[][] readData = ReadExcel.readData(filename);
		return readData;

	}

}
