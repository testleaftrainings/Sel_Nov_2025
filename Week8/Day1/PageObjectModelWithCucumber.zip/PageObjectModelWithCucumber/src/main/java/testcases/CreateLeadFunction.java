package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLeadFunction extends BaseClass{
	@BeforeTest
	public void setValues() {
		filename="CreateLead";

	}
	
	
	
	@Test(dataProvider = "sendData")
	public void createLead(String username,String password,String companyName,String firstName,String lastName) {
		LoginPage lp=new LoginPage();          //acbd1234     
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLeadButton()
		.verifyLead();

	}

}
